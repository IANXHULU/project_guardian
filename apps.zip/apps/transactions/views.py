from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions

from .serializers import TransactionCreateSerializer
from apps.telecom.services import run_telecom_checks
from apps.risk.engine import assess_transaction


class TransactionCreateView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = TransactionCreateSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        transaction = serializer.save()

        telecom_data = run_telecom_checks(transaction)
        risk_result = assess_transaction(transaction, telecom_data)

        return Response(
            {
                "success": True,
                "transaction_id": str(transaction.id),
                "status": transaction.status,
                "risk_score": risk_result["score"],
                "risk_level": risk_result["risk_level"],
                "decision": risk_result["decision"],
                "explanation": risk_result["explanation"],
                "references": risk_result["references"],
                "telecom_checks": telecom_data,
            },
            status=status.HTTP_201_CREATED,
        )