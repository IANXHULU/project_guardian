import uuid
from django.db import models


class Tenant(models.Model):
    TENANT_TYPES = [
        ("fintech", "Fintech"),
        ("mno", "Mobile Network Operator"),
        ("bank", "Bank"),
        ("merchant", "Merchant"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255)
    tenant_type = models.CharField(max_length=50, choices=TENANT_TYPES)
    api_key = models.CharField(max_length=255, unique=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name