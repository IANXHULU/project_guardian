from django.contrib import admin
from .models import Tenant


@admin.register(Tenant)
class TenantAdmin(admin.ModelAdmin):
    list_display = ("name", "tenant_type", "api_key", "is_active", "created_at")
    search_fields = ("name", "api_key")
    list_filter = ("tenant_type", "is_active")