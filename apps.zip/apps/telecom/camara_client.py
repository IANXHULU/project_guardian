import requests
from django.conf import settings


class CamaraClientError(Exception):
    pass


class CamaraClient:
    def __init__(self):
        self.base_url = settings.CAMARA_BASE_URL
        self.api_key = settings.CAMARA_API_KEY
        self.host = settings.CAMARA_HOST
        self.timeout = settings.CAMARA_TIMEOUT

    def post(self, path: str, payload: dict) -> dict:
        if not self.base_url:
            raise CamaraClientError("CAMARA_BASE_URL is not configured.")

        if not self.api_key:
            raise CamaraClientError("CAMARA_API_KEY is not configured.")

        url = f"{self.base_url.rstrip('/')}/{path.lstrip('/')}"

        response = requests.post(
            url,
            json=payload,
            headers={
                "x-rapidapi-key": self.api_key,
                "x-rapidapi-host": self.host,
                "Content-Type": "application/json",
            },
            timeout=self.timeout,
        )

        if response.status_code >= 400:
            raise CamaraClientError(
                f"CAMARA request failed: {response.status_code} {response.text}"
            )

        return response.json()