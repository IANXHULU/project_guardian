from django.urls import path
from .views import DashboardSummaryView, GuardianDashboardView


urlpatterns = [
    path("", GuardianDashboardView.as_view(), name="guardian-dashboard"),
    path("summary/", DashboardSummaryView.as_view(), name="dashboard-summary"),
]