from rest_framework.views import APIView
from rest_framework.response import Response
from .services.transaction_processor import process_transaction


class TransactionProcessView(APIView):

    def post(self, request):
        transaction_data = request.data

        result = process_transaction(transaction_data)

        return Response(result)