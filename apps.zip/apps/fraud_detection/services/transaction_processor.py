from .sim_swap import check_sim_swap
from .device_swap import check_device_swap
from .location_check import verify_location
from .velocity_check import detect_velocity_fraud
from .aml_check import check_high_value_transaction
from .graph_check import detect_graph_fraud
from .risk_engine import calculate_risk_score
from .decision_engine import determine_transaction_action


def process_transaction(transaction):

    results = []

    results.append(check_sim_swap(transaction))
    results.append(check_device_swap(transaction))
    results.append(verify_location(transaction))
    results.append(detect_velocity_fraud(transaction))
    results.append(check_high_value_transaction(transaction))
    results.append(detect_graph_fraud(transaction))

    risk_score = calculate_risk_score(results)

    decision = determine_transaction_action(risk_score)

    return {
        "risk_score": risk_score,
        "decision": decision,
        "checks": results
    }