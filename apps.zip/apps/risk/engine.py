from .models import RiskAssessment
from apps.risk.aml_engine import run_aml_rules
from apps.cases.models import FraudCase
from apps.transactions.models import Transaction
from apps.alerts.services import create_critical_fraud_alert



def assess_transaction(transaction, telecom_data):
    score = 0
    reasons = []
    references = []

    number_verification = telecom_data.get("number_verification", {})
    sim_swap = telecom_data.get("sim_swap", {})
    device_swap = telecom_data.get("device_swap", {})
    location_verification = telecom_data.get("location_verification", {})

    if number_verification.get("failed"):
        score += number_verification.get("score", 35)
        reasons.append("Number verification failed")
        references.append(number_verification.get("reference"))

    if sim_swap.get("recent"):
        score += sim_swap.get("score", 40)
        reasons.append("Recent SIM swap detected")
        references.append(sim_swap.get("reference"))

    if device_swap.get("swapped"):
        score += device_swap.get("score", 25)
        reasons.append("Device swap detected")
        references.append(device_swap.get("reference"))

    if location_verification.get("mismatch"):
        score += location_verification.get("score", 25)
        reasons.append("Location verification mismatch")
        references.append(location_verification.get("reference"))
    
    kyc_match = telecom_data.get("kyc_match", {})
    if kyc_match.get("failed"):
        score += kyc_match.get("score", 30)
        reasons.append("KYC match failed")
        references.append(kyc_match.get("reference"))

    kyc_tenure = telecom_data.get("kyc_tenure", {})
    if kyc_tenure.get("failed"):
        score += kyc_tenure.get("score", 25)
        reasons.append("Low KYC tenure")
        references.append(kyc_tenure.get("reference"))

    aml_result = run_aml_rules(transaction)

    score += aml_result["score"]
    reasons.extend(aml_result["reasons"])
    references.extend(aml_result["references"])
    
    if decision == "BLOCK":
        FraudCase.objects.get_or_create(
            transaction=transaction,
            defaults={
                "title": f"Critical Fraud Investigation - {transaction.id}",
                "description": (
                    f"Guardian automatically created this case after detecting "
                    f"critical fraud signals for transaction "
                    f"{transaction.id}."
                ),
                "priority": "critical",
                "status": "open",
            }
        )
    if decision == "BLOCK":
        create_critical_fraud_alert(
            transaction=transaction,
            risk_result={
                "score": score,
                "risk_level": risk_level,
                "decision": decision,
                "explanation": explanation,
            },
        )

    if score >= 90:
        decision = "BLOCK"
        status = "blocked"
        risk_level = "critical"
    elif score >= 60:
        decision = "DELAY"
        status = "delayed"
        risk_level = "high"
    elif score >= 30:
        decision = "FLAG"
        status = "flagged"
        risk_level = "medium"
    else:
        decision = "ALLOW"
        status = "approved"
        risk_level = "low"

    explanation = "; ".join(reasons) if reasons else "No major fraud indicators detected"

    clean_references = [ref for ref in references if ref]

    if clean_references:
        explanation = f"{explanation}. References: {', '.join(clean_references)}"

    transaction.status = status
    transaction.risk_score = score
    transaction.save(update_fields=["status", "risk_score"])

    assessment, _ = RiskAssessment.objects.update_or_create(
        transaction=transaction,
        defaults={
            "total_score": score,
            "risk_level": risk_level,
            "decision": decision,
            "explanation": explanation,
        },
    )

    return {
        "assessment": assessment,
        "score": score,
        "risk_level": risk_level,
        "decision": decision,
        "explanation": explanation,
        "references": clean_references,
    }